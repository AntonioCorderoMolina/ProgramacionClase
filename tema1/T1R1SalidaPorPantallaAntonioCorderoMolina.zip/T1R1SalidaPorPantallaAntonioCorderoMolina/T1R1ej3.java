package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej3 {
                        //MUestra por pantalla una palabra por inglés y su traducción
    public static void main(String[] args){
        //Sin tabuladores
        System.out.printf("%-15s%s\n", "computer", "ordenador");   //Corrección
        System.out.printf("%-15salumno\n", "student");
        System.out.printf("%-15sgato\n", "caat");
        System.out.printf("%-15sperro\n", "dog");
        System.out.printf("%-15smáquina\n", "machine");
        System.out.printf("%-15spingüino\n", "penguin");
        System.out.printf("%-15sluz\n", "light");
        System.out.printf("%-15sverde\n", "green");
        System.out.printf("%-15slibro\n", "book");
        System.out.printf("%-15sprirámide\n", "pyramid");

        //Con tabuladores (Corrección)
        System.out.printf("ordenador\t\tcomputer");
        System.out.printf("alumno\t\tstudent");
        System.out.printf("gato\t\taat");
        System.out.printf("perro\t\tdog");

    }
}