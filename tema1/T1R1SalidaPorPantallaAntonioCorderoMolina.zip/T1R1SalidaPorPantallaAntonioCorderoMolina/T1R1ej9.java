package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej9 {
    //Muestra un dibujo por pantalla
    public static void main(String[] args) {
        System.out.println("  \u25A0  ");
        System.out.println(" \u25A0 \u25A0 ");
        System.out.println("\u25A0   \u25A0");
        System.out.println("\u25A0\u25A0\u25A0\u25A0\u25A0");
        System.out.println("\u25A0   \u25A0");
        System.out.println("\u25A0   \u25A0");
    }
}