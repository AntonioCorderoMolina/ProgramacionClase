package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej5 {
            //Muestra un dibujo por pantalla el horario de clase COLOREADO
    public static void main(String[] args) {
        System.out.println("Lunes   Martes  Miercoles   Jueves  Viernes");
        System.out.println("-------------------------------------------");
        System.out.println("\033[32mProg  |  Prog\033[0m  | \033[31mSInf\033[0m    |   \033[36mBBDD\033[0m  | \033[31mSInf\033[0m");
        System.out.println("\033[32mProg  |  Prog\033[0m  | \033[31mSInf\033[0m    |   \033[36mBBDD\033[0m  | \033[31mSInf\033[0m");
        System.out.println("\033[33mLM    |  LM\033[0m    | \033[31mSInf\033[0m    |   \033[35mED\033[0m    | \033[31mSInf\033[0m");
        System.out.println("\033[33mLM    |  LM\033[0m    | \033[32mProg\033[0m    |   \033[35mED\033[0m    | FOL");
        System.out.println("\033[36mBBDD  |  BBDD\033[0m  | \033[32mProg    |   Prog\033[0m  | FOL");
        System.out.println("\033[36mBBDD  |  BBDD\033[0m  | \033[35mED\033[0m      |   \033[32mProg\033[0m  | FOL");
    }
}

