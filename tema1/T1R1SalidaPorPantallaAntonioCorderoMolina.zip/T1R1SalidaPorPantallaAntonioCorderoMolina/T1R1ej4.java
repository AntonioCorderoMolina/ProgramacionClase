package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej4 {
        //Muestra un dibujo por pantalla el horario de clase
    public static void main(String[] args) {
    System.out.println("Lunes   Martes  Miercoles   Jueves  Viernes");
    System.out.println("Prog    Prog    SInf        BBDD    SInf");
    System.out.println("Prog    Prog    SInf        BBDD    SInf");
    System.out.println("LM      LM      SInf        ED      SInf");
    System.out.println("LM      LM      Prog        ED      FOL");
    System.out.println("BBDD    BBDD    Prog        Prog    FOL");
    System.out.println("BBDD    BBDD    ED          Prog    FOL");
    }
}
