package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej10 {
    //Muestra un dibujo por pantalla COLOREADO
    public static void main(String[] args) {
        System.out.println("\033[31m  \u25A0  ");
        System.out.println("\033[31m \u25A0 \u25A0");
        System.out.println("\033[31m\u25A0   \u25A0");
        System.out.println("\033[31m\u25A0\u25A0\u25A0\u25A0\u25A0");
        System.out.println("\033[31m\u25A0   \u25A0");
        System.out.println("\033[31m\u25A0   \u25A0");
        System.out.println("\033[31m\u25A0   \u25A0 \033[0m\n");
    }
}