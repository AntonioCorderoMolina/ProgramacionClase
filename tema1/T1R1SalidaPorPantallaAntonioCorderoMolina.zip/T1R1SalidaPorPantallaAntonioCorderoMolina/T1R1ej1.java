package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej1 {
        //Muestra mi nombre por pantalla
    public static void main(String[] args){
    System.out.println("Antonio Cordero Molina");
    }
}
