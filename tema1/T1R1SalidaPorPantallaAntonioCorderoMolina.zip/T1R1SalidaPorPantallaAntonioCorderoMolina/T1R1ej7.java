package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej7 {
    public static void main(String[] args) {
        String pyramid = "        *\n" +
                        "       * *\n" +
                        "      *   *\n" +
                        "     *     *\n" +
                        "    *       *\n" +
                        "   *         *\n" +
                        "  *           *\n" +
                        " *             *\n" +
                        "*****************";
        
        System.out.println(pyramid);
    }
}
