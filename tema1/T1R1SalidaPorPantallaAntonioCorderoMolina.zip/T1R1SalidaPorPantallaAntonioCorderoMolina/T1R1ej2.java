package T1R1SalidaPorPantallaAntonioCorderoMolina;

public class T1R1ej2 {
        //Muestra mi nombre por pantalla, dirección, número teléfono:
    public static void main(String[] args){
    System.out.println("Nombre: Antonio Cordero Molina");
    System.out.println("Dirección: C/ Calle nº x");
    System.out.println("Número teléfono: +34 621373845");
    }
}