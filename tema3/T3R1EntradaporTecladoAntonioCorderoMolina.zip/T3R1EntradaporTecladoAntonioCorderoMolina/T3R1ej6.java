package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej6 {
    
    //Programa que calcule el area de un triángulo (a= (b*h)/2)
    public static void main(String[] args) {
                
        Scanner s = new Scanner(System.in) ;

        System.out.println("\nCálculo del área de un triángulo") ;
        System.out.println("-----------------------------------") ;
        System.out.printf("Introduzca la longitud de la base (cm): ") ;
        float base = s.nextFloat() ;
        System.out.printf("Introduzca la altura (cm): ") ;
        float altura = s.nextFloat() ;

        System.out.printf("El área de un triángulo es %.1f cm^2\n", ((base * altura)/2)) ;

        s.close();
    }
}
