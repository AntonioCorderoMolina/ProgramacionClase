package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej9 {
    
    //Programa que calcule el volumen de un cono según la fórmula V = ((3.14*r*r*h)/3);
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;

        System.out.println("Volumen de un cono") ;
        System.out.println("------------------") ;
        System.out.printf("Introduzca la altura (cm): ") ;
        float altura = s.nextFloat() ;
        System.out.printf("Introduzca la base (cm): ") ;
        float radioBase = s.nextFloat() ;

        System.out.printf("El volumen del cono es de %.11f cm^3\n", (((3.14*((radioBase)*(radioBase))*altura))/3)) ;

    s.close();
    }

}
