package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej5 {

    //Programa que calcule el area de un rectángulo (a=b*h)
    public static void main(String[] args) {
            
        Scanner s = new Scanner(System.in) ;

        System.out.println("\nCálculo del área de un rectángulo") ;
        System.out.println("-----------------------------------") ;
        System.out.printf("Introduzca la longitud de la base (cm): ") ;
        float base = s.nextFloat() ;
        System.out.printf("Introduzca la altura (cm): ") ;
        float altura = s.nextFloat() ;

        System.out.printf("El área de un rectágulo es %.1f cm^2 \n", (base * altura)) ;


    s.close();
    }
}
