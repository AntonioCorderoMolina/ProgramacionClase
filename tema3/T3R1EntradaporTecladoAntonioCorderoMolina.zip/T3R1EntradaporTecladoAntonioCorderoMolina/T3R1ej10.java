package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej10 {
    
    //Programa que haga la conversion de Mb a Kb (1Mb = 1024Kb)
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;

        System.out.printf("\nIntroduzca el número de Mb: ") ;
        float megaBytes = s.nextFloat() ;

        System.out.printf("%.1fMb son %.1fKb", megaBytes, (megaBytes * 1024)) ;
    

    s.close() ;
    }
}
