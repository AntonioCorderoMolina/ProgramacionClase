package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej7 {

    //Programa que calcule el total de una factura a partir de la base imponible
    public static void main(String[] args) {
                
        Scanner s = new Scanner(System.in) ;

        System.out.printf("\nIntroduzca la base imponible (precio del articulo sin IVA): ") ;
        float precio = s.nextFloat();
        System.out.printf("Base impnible\t%.2f €\n", precio) ;
        System.out.printf("IVA (21%%)\t %.2f €\n", (precio * 0.21)) ;
        System.out.println("------------------------") ;
        System.out.printf("Total\t\t %.2f €\n", (precio + (precio * 0.21))) ;

    s.close();
    }
}
