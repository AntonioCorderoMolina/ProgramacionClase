package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej1 {
   
    //Programa que pida dos numeros enteros y muestre el resultado de su multiplicación
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;

        System.out.println("\nEste programa multiplica dos nummeros enteros") ;

        System.out.printf("Introduce un primer número: ") ;
        int numero1 = s.nextInt() ;

        System.out.printf("Introduce un segundo número: ") ;
        int numero2 = s.nextInt() ;

        System.out.println("Resultado de la multiplicación " + numero1 + " * " + numero2 + " = " + (numero1 * numero2)) ;
    
        s.close();
    }
}
