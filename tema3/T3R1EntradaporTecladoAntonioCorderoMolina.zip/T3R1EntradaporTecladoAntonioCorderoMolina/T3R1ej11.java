package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej11 {

    //Conversor de Kb a Mb (1024Kb = 1Mb)
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;
        
        System.out.print("\nIntroduzca el número de Kb: ") ;
        float kiloBytes = s.nextFloat() ;

        System.out.printf("%.0fKb son %.1fMb \n", kiloBytes, (kiloBytes / 1024)) ;


    s.close();
    }
}
