package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej3 {
    
    //Conversor pesetas a euros
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;

        System.out.printf("\nIntroduzca la cantidad de euros que quiere convertir: ") ;
        int pesetas = s.nextInt() ;
        
        //**Cambio de pesetas a euros (1 peseta / 166.3 euros)**

        System.out.printf(pesetas + " pesetas son" + (pesetas * 166.3) + "euros.") ;

        s.close();
    }
}
