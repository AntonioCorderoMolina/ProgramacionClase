package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej2 {
    
    //Conversor euros a pesetas
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;

        System.out.printf("\nIntroduzca la cantidad de euros que quiere convertir: ") ;
        float euros = s.nextFloat() ;
        
        //**Cambio de euros a pesetas (1 euro * 166.3 pesetas)**
        
        //float pesetas = (int) (euros * 166.3) ;

        //System.out.printf("euros", euros, " son %.0f ", pesetas, " pesetas ") ;
        System.out.printf(euros + " euros son " + (euros * 166.3) + " pesetas. ") ;

        s.close();
    }

}
