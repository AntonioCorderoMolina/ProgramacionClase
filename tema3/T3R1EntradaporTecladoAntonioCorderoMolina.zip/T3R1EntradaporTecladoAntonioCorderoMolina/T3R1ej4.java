package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej4 {
    
//Programa que multiplique y divida dos números introducidos por teclado (pueden tener decimales)
    public static void main(String[] args) {
            
        Scanner s = new Scanner(System.in) ;

        System.out.printf("\nIntroduzca el primer número: ") ;
        double x = s.nextDouble() ;

        System.out.printf("\nIntroduzca el segundo número: ") ;
        double y = s.nextDouble() ;

        System.out.println("x = " + x) ;
        System.out.println("y = " + y) ;
        System.out.println("x + y = " + (x + y)) ;
        System.out.println("x - y = " + (x - y)) ;
        System.out.printf("x / y = %.17f\n", (x / y)) ;
        System.out.println("x * y = " + (x * y)) ;

        
        s.close();
    }
}
