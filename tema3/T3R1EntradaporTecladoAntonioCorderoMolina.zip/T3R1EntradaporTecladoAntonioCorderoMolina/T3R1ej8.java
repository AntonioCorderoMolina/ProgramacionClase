package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej8 {
    
    //Programa que calcule el sueldo semanal de un empleado en base a las horas (12€/h)
    public static void main(String[] args) {
                
        Scanner s = new Scanner(System.in) ;

        System.out.print("\nIntroduzca el número de horas trabajadas durante la semana: ") ;
        int horas = s.nextInt() ;
        
        System.out.println("Su salario semanal es de " + (horas * 12) + " euros") ;

    s.close();
    }
}
