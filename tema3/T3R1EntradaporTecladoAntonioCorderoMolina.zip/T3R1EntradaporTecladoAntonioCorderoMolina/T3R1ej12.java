package tema3.T3R1EntradaporTecladoAntonioCorderoMolina;

import java.util.Scanner ;

public class T3R1ej12 {
    
    //Programa que calcule la note necesaria en el segundo examen para obtener la media deseada.
    //Nota primer examen = 40%
    //Nota segundo examen = 60%
    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in) ;

        System.out.print("\nIntroduzca la nota del primer exmanen: ") ;
        float nota1 = s.nextFloat() ;
        System.out.printf("¿Qué nota quiere sacar en el trimestre? ") ;
        float media = s.nextFloat() ;

        System.out.printf("Para tener un %.1f en el trimestre necesita sacar un %.1f en el segundo examen \n "
                                                                            , media, ((media - (nota1 * 0.4))/0.6)) ;

    s.close() ;
    }

}
