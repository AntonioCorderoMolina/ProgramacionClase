package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej5 {
    
    //Conversor pesetas a euros

    public static void main(String[] args) {
    
        int pesetas = 10000 ;
        float euros = (float) (pesetas / 166.39) ;

        System.out.printf(pesetas + " pesetas equivalen a %.2f" + euros + " euros\n") ;

    }

}
