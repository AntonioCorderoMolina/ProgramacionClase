package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej7 {

    //Declarar variables tipo char y tipo String y mostrarlas todas juntas por pantalla

    public static void main(String[] args) {
        
        char primeraLetra = 'a' ;
        char ultimaLetra = 'z' ;

        String abc = "abecedario" ;

        System.out.println("Solución: " + primeraLetra + ultimaLetra + abc) ;

    }
    
}
