package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej6 {
    
    //Programa que calcule el total de una factura
    public static void main(String[] args) {
      
        double baseImponible = 22.75 ;
        double iva = 4.78 ;

        //baseImponible = (float) 22.75 ;
        //iva = (float) 4.78 ;

        System.out.printf("\nBase Imponible\t %.2f", baseImponible, "\n") ;
        System.out.printf("\nIVA\t\t %.2f", iva, "\n") ;
        System.out.printf("\n----------------------\n") ;
        System.out.printf("Total\t\t %.2f", (baseImponible + iva), "\n") ;

    }

}
