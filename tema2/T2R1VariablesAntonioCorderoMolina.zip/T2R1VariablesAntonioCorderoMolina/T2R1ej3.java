package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej3 {
        
    //Muestra por pantalla nombre, dirección y teléfono

    public static void main(String[] args) {
        
        String nombre = "Antonio Cordero" ;
        String direccion = "C/ Calle nº n" ;
        String tlf = "+34 621373845" ;

        System.out.println(nombre) ;
        System.out.println(direccion) ;
        System.out.println(tlf) ;
    
    }
}
