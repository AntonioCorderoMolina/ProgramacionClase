package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2E1ej2 {
    
    public static void main(String[] args) {
        
        //Imprimir nombre por pantalla

        String nombre = "Antonio Cordero" ;

        System.out.println("Hola, mi nombre es: " + nombre) ;
    }

}