package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej8 {
    
    //Programa que declare 5 variables tipo char y concatenación de las 5 anteriores variables

    public static void main(String[] args) {

        char letra1 = 'H' ;
        char letra2 = 'o' ;
        char letra3 = 'l' ;
        char letra4 = 'a' ;
        
        String concatenacion = ("\n" + letra1 + letra2 + letra3 + letra4) ;

        System.out.println(concatenacion) ;

    }
}
