package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej1 {
    public static void main(String[] args) {
        
        float x ;
        float y ;

        x = 144 ;
        y = 999 ;

        float suma ;
        float resta ;
        float multiplicacion ;
        float division ;

        suma = x + y ;
        resta = x - y ;
        multiplicacion = x * y ;
        division = x / y ;

        System.out.printf("x = %.0f\n", x) ;
        System.out.printf("y = %.0f\n", y) ;
        System.out.printf("x + y = %.0f\n", suma) ;
        System.out.printf("x - y = %.0f\n", resta) ;
        System.out.printf("x * y = %.0f\n", multiplicacion) ;
        System.out.printf("x / y = %.8f\n", division) ;
    }
}
