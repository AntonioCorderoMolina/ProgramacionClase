package tema2.T2R1VariablesAntonioCorderoMolina;

public class T2R1ej4 {
    
    //Conversor de euros a pesetas

    public static void main (String[] args){

        float euros = 6.0f ;

        //euros = 6.0 ;
        //float pesetas = (euros * 166.39) ;

        //System.out.println(euros + " euros equivalen a " + pesetas + " pesetas.");
        
        System.out.printf("euros equivalen a %.3f\n", euros * 166.39) ;
    }

}
